"use strict";
exports.id = 69;
exports.ids = [69];
exports.modules = {

/***/ 5588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/chevron-left.ea9fb68d.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 2189:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/chevron-right.9dfe187c.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 3006:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/github.a2e2fa59.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 8312:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/info.e2ca7af6.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 7993:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/pause-circle.e1f4e2c2.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 6344:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/play-circle.9a0640fd.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 156:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);



const landscapeImages = [
    "/landscape/IMG_6328.jpg",
    "/landscape/IMG_6323.jpg",
    "/landscape/IMG_0234.jpg",
    "/landscape/IMG_6324.jpg",
    "/landscape/IMG_4605.jpg"
];
const portraitImages = (/* unused pure expression or super */ null && ([
    "/portrait/IMG_0236.jpg",
    "/portrait/IMG_0237.jpg",
    "/portrait/IMG_0597.jpg",
    "/portrait/IMG_7036.jpg",
    "/portrait/IMG_2052.jpg"
]));
const BackgroundImage = ({ status , timer  })=>{
    const [currentImageFile, setCurrentImageFile] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(landscapeImages);
    const [currentImageIndex, setCurrentImageIndex] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (status) {
            const interval = setInterval(()=>{
                setCurrentImageIndex((prevIndex)=>(prevIndex + 1) % currentImageFile.length);
            }, timer);
            return ()=>{
                clearInterval(interval);
            };
        }
    }, [
        status,
        timer,
        currentImageFile.length
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (currentImageFile && currentImageFile.length > 0) {
            setCurrentImageFile(currentImageFile);
        }
    }, [
        currentImageIndex,
        currentImageFile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (false) {}
    }, []);
    const image = currentImageFile[currentImageIndex];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "top-0 left-0 w-screen h-screen overflow-hidden",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-full absolute inset-0 z-[-1]",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                src: image,
                alt: "Background Image",
                layout: "fill",
                objectFit: "cover"
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BackgroundImage);


/***/ }),

/***/ 6187:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);




const pauseIcon = __webpack_require__(7993);
const playIcon = __webpack_require__(6344);
const github = __webpack_require__(3006);
const GlassButton = ({ text , isPlaying , playing , displayImageButton , image , link , type , buttonClass , border  })=>{
    const handleDownload = ()=>{
        alert("Christian CV 2023 EN - Developer.pdf");
    // const fileName = "Christian CV 2023 EN - Developer.pdf";
    // const encodedFileName = encodeURIComponent(fileName);
    // const downloadUrl = `/${encodedFileName}`;
    // const link = document.createElement("a");
    // link.href = downloadUrl;
    // link.download = fileName;
    // link.click();
    };
    const [slideShowButton, setSlideShowButton] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(playing ? pauseIcon : playIcon);
    const openOnGithub = ()=>{
        alert("Opening ", JSON.stringify(link), "on github");
    };
    const changeStatus = ()=>{
        if (!playing) {
            isPlaying(true);
            setSlideShowButton(pauseIcon);
        }
        if (playing) {
            isPlaying(false);
            setSlideShowButton(playIcon);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            !type && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                onClick: changeStatus,
                className: ` ${!border ? "" : "glass-button"}`,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "glass-text-button",
                        children: [
                            " ",
                            text || ""
                        ]
                    }),
                    displayImageButton && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                        src: slideShowButton,
                        alt: "slideshow controls",
                        className: `w-8 h-8 mix-blend-overlay`
                    }),
                    image && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                        src: image,
                        alt: "slideshow controls",
                        className: "w-8 h-8 mix-blend-overlay "
                    })
                ]
            }),
            type === "textButton" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: handleDownload,
                className: "glass-button",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-bold text-lg sm:text-xl text-white mix-blend-overlay px-4 py-2",
                    style: {
                        letterSpacing: "2px"
                    },
                    children: text || ""
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GlassButton);


/***/ }),

/***/ 6917:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const Cursor = ({ isVisible  })=>{
    const [mousePosition, setMousePosition] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        x: 0,
        y: 0
    });
    const [cursorVariant, setCursorVariant] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("default");
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const mouseMove = (e)=>{
            setMousePosition({
                x: e.clientX,
                y: e.clientY
            });
        };
        window.addEventListener("mousemove", mouseMove);
        return ()=>{
            window.removeEventListener("mousemove", mouseMove);
        };
    }, []);
    const variants = {
        default: {
            x: mousePosition.x - 16,
            y: mousePosition.y - 16,
            transition: {
                duration: 0
            }
        },
        text: {
            height: 75,
            width: 75,
            x: mousePosition.x - 75,
            y: mousePosition.y - 75,
            backgroundColor: "black",
            mixBlendMode: "overlay",
            backdropFilter: "0px",
            transition: {
                duration: 0
            }
        }
    };
    const textEnter = ()=>setCursorVariant("text");
    const textLeave = ()=>setCursorVariant("default");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
        className: isVisible ? "cursor" : "cursor-default",
        variants: variants,
        animate: cursorVariant
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cursor);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;