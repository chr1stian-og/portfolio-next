"use strict";
exports.id = 279;
exports.ids = [279];
exports.modules = {

/***/ 5279:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);




const previous = __webpack_require__(5588);
const next = __webpack_require__(2189);
const info = __webpack_require__(8312);
const GlassFrame = ({ onClick , title , image , onClose , description  })=>{
    return /*#__PURE__*/ _jsx("div", {
        onClick: onClick,
        className: "glass-frame",
        children: /*#__PURE__*/ _jsxs("div", {
            className: "flex flex-row justify-between items-center",
            children: [
                /*#__PURE__*/ _jsx(Image, {
                    src: previous,
                    className: "w-8 h-8 mix-blend-overlay ",
                    alt: "previous"
                }),
                /*#__PURE__*/ _jsxs("div", {
                    children: [
                        /*#__PURE__*/ _jsxs("span", {
                            className: "glass-text-button",
                            children: [
                                " ",
                                title
                            ]
                        }),
                        /*#__PURE__*/ _jsxs("span", {
                            className: "glass-text-button",
                            children: [
                                " ",
                                description
                            ]
                        }),
                        /*#__PURE__*/ _jsx(Image, {
                            src: info,
                            className: "w-6 h-6 mix-blend-overlay ",
                            alt: "indo"
                        })
                    ]
                }),
                /*#__PURE__*/ _jsx(Image, {
                    src: next,
                    className: "w-6 h-6 mix-blend-overlay ",
                    alt: "next"
                })
            ]
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (GlassFrame)));


/***/ })

};
;